/**
 * Nyyo Sheets kit 1.0.0 - one-file copy-paste version, built from apps-script/ by setup.
 * Paste ALL of this into Extensions > Apps Script (replace what is there), click Save,
 * choose nyyoSetup next to Run, click Run and allow access. Then reload the spreadsheet tab.
 */

// ===== Config.gs =====
/**
 * Nyyo Sheets kit 1.0.0 - free 1-click install kit (MIT licence), Nyyo Automation.
 * Clean a messy "Data" tab into a "Clean" tab, build a "Dashboard", stamp edited rows,
 * and (optional) refresh everything once a day. Everything stays in your own spreadsheet.
 *
 * @OnlyCurrentDoc  (the kit can only open the spreadsheet it is installed in)
 *
 * Settings you may change: tab names, which column identifies a client, accepted statuses,
 * sort order and the hour of the daily refresh. Column order in "Data" does not matter:
 * columns are found by their header name (upper or lower case both work).
 */
var NYYO = {
  version: '1.0.0',
  tabs: { data: 'Data', clean: 'Clean', dashboard: 'Dashboard', howto: 'How to use', log: 'Change log' },
  // Columns of the Data tab. The kit adds any that are missing at the end, never removes one.
  headers: ['client_id', 'name', 'phone', 'signup_date', 'amount_usd', 'status', 'city', 'last_updated'],
  keyColumn: 'client_id',        // duplicates = same client_id (or same name + phone when client_id is empty)
  statuses: ['paid', 'pending'], // any other status is flagged for review, never deleted
  timestampColumn: 'last_updated',
  sortBy: ['signup_date', 'name'],
  dailyRefreshHour: 6,           // 0-23, in the spreadsheet's time zone
  logMaxRows: 500,
  cleanHeaders: ['client_id', 'name', 'phone', 'signup_date', 'amount_usd', 'status', 'city', 'notes']
};

// ===== Clean.gs =====
/** Cleaning rules (pure functions: no spreadsheet access, unit-tested on their own). */

function nyyoNormText_(v) {
  return String(v === null || v === undefined ? '' : v).replace(/\s+/g, ' ').trim();
}

function nyyoNormName_(v) {
  return nyyoNormText_(v).toLowerCase().replace(/(^|[\s'-])([a-z\u00e0-\u00ff])/g, function (m, p, c) {
    return p + c.toUpperCase();
  });
}

function nyyoNormKey_(v) {
  return nyyoNormText_(v).toUpperCase();
}

function nyyoNormPhone_(v) {
  var digits = nyyoNormText_(v).replace(/\D/g, '');
  return digits.length >= 6 ? digits : '';
}

function nyyoPad_(n) { return (n < 10 ? '0' : '') + n; }

function nyyoValidYmd_(y, m, d) {
  if (y < 1900 || y > 2100 || m < 1 || m > 12 || d < 1) return null;
  var days = [31, (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (d > days[m - 1]) return null;
  return y + '-' + nyyoPad_(m) + '-' + nyyoPad_(d);
}

var NYYO_MONTHS_ = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };

/**
 * Any date -> 'YYYY-MM-DD', or null when it cannot be read safely.
 * Date cells are read in the spreadsheet's time zone. Text is tried in this order:
 * 2025-01-15, 01/15/2025 (month first), 15/01/2025 (day first), 2025/01/15, 15-01-2025, Jan 15 2025, 15/01/25.
 */
function nyyoParseDate_(v, tz) {
  if (v instanceof Date) {
    if (isNaN(v.getTime())) return null;
    return Utilities.formatDate(v, tz || 'Etc/UTC', 'yyyy-MM-dd');
  }
  var s = nyyoNormText_(v), m;
  if (!s) return null;
  if ((m = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(s))) return nyyoValidYmd_(+m[1], +m[2], +m[3]);
  if ((m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(s))) {
    return nyyoValidYmd_(+m[3], +m[1], +m[2]) || nyyoValidYmd_(+m[3], +m[2], +m[1]);
  }
  if ((m = /^(\d{4})\/(\d{1,2})\/(\d{1,2})$/.exec(s))) return nyyoValidYmd_(+m[1], +m[2], +m[3]);
  if ((m = /^(\d{1,2})-(\d{1,2})-(\d{4})$/.exec(s))) return nyyoValidYmd_(+m[3], +m[2], +m[1]);
  if ((m = /^([A-Za-z]{3})[a-z]*\.? (\d{1,2}),? (\d{4})$/.exec(s))) {
    var mon = NYYO_MONTHS_[m[1].toLowerCase()];
    return mon ? nyyoValidYmd_(+m[3], mon, +m[2]) : null;
  }
  if ((m = /^(\d{1,2})\/(\d{1,2})\/(\d{2})$/.exec(s))) return nyyoValidYmd_(2000 + +m[3], +m[2], +m[1]);
  return null;
}

/** '$1,200.50', '2,100.00 USD', '450,75', '1 350', 1200.5 -> number rounded to cents, or null. */
function nyyoParseAmount_(v) {
  if (typeof v === 'number') return isFinite(v) ? Math.round(v * 100) / 100 : null;
  var s = nyyoNormText_(v).replace(/[^0-9,.\-]/g, '');
  if (!s) return null;
  if ((s.match(/,/g) || []).length === 1 && s.indexOf('.') === -1) s = s.replace(',', '.');
  else s = s.replace(/,/g, '');
  if (!/^-?\d+(\.\d+)?$/.test(s)) return null;
  return Math.round(parseFloat(s) * 100) / 100;
}

/** Finds each wanted column by header name. Returns { name: index } and throws on a missing required column. */
function nyyoColumnMap_(header, required) {
  var map = {};
  for (var i = 0; i < header.length; i++) {
    var h = nyyoNormText_(header[i]).toLowerCase();
    if (h && !(h in map)) map[h] = i;
  }
  var missing = required.filter(function (r) { return !(r in map); });
  if (missing.length) throw new Error('Missing column(s) in the Data tab: ' + missing.join(', ') + '. Run "1. Set up" to add them.');
  return map;
}

/**
 * The cleaning itself. rows = Data values without the header.
 * Returns { rows: [[...cleanHeaders]], kept, merged, review, skipped }.
 * Rows with no name are skipped (empty lines). Rows with a bad date, amount or status are kept at the
 * bottom with a note, never deleted. Duplicates (same key) are merged into the first one.
 */
function nyyoCleanRows_(header, rows, cfg, tz) {
  var need = ['name', 'phone', 'signup_date', 'amount_usd', 'status', 'city', cfg.keyColumn];
  var col = nyyoColumnMap_(header, need);
  var byKey = {}, order = [], review = [], skipped = 0, merged = 0;
  rows.forEach(function (r) {
    var name = nyyoNormName_(r[col.name]);
    if (!name) { skipped++; return; }
    var rec = {
      client_id: nyyoNormKey_(r[col[cfg.keyColumn]]),
      name: name,
      phone: nyyoNormPhone_(r[col.phone]),
      signup_date: nyyoParseDate_(r[col.signup_date], tz),
      amount_usd: nyyoParseAmount_(r[col.amount_usd]),
      status: nyyoNormText_(r[col.status]).toLowerCase(),
      city: nyyoNormName_(r[col.city]),
      notes: ''
    };
    var problems = [];
    if (rec.signup_date === null) problems.push('date');
    if (rec.amount_usd === null) problems.push('amount');
    if (cfg.statuses.indexOf(rec.status) === -1) problems.push('status');
    if (problems.length) {
      rec.notes = 'NEEDS REVIEW: ' + problems.join(', ');
      review.push(rec);
      return;
    }
    var key = rec.client_id || (rec.name.toLowerCase() + '|' + rec.phone);
    if (byKey[key]) { byKey[key].notes = 'merged duplicate rows'; merged++; return; }
    byKey[key] = rec;
    order.push(key);
  });
  var kept = order.map(function (k) { return byKey[k]; });
  var sortBy = cfg.sortBy || [];
  kept.sort(function (a, b) {
    for (var i = 0; i < sortBy.length; i++) {
      var x = String(a[sortBy[i]]).toLowerCase(), y = String(b[sortBy[i]]).toLowerCase();
      if (x < y) return -1;
      if (x > y) return 1;
    }
    return 0;
  });
  var out = kept.concat(review).map(function (rec) {
    return cfg.cleanHeaders.map(function (h) {
      var v = rec[h];
      return v === null || v === undefined ? '' : v;
    });
  });
  return { rows: out, kept: kept.length, merged: merged, review: review.length, skipped: skipped };
}

/** Dashboard figures from the cleaned rows. */
function nyyoSummary_(cleanRows, cfg) {
  var c = {}; cfg.cleanHeaders.forEach(function (h, i) { c[h] = i; });
  var s = { clients: 0, review: 0, paid: 0, pending: 0, paidCount: 0, pendingCount: 0, cities: {} };
  cleanRows.forEach(function (r) {
    if (String(r[c.notes]).indexOf('NEEDS REVIEW') === 0) { s.review++; return; }
    s.clients++;
    var amt = Number(r[c.amount_usd]) || 0;
    if (r[c.status] === 'paid') { s.paid += amt; s.paidCount++; }
    if (r[c.status] === 'pending') { s.pending += amt; s.pendingCount++; }
    var city = r[c.city] || '(no city)';
    if (!s.cities[city]) s.cities[city] = { count: 0, amount: 0 };
    s.cities[city].count++;
    s.cities[city].amount += amt;
  });
  s.paid = Math.round(s.paid * 100) / 100;
  s.pending = Math.round(s.pending * 100) / 100;
  Object.keys(s.cities).forEach(function (k) { s.cities[k].amount = Math.round(s.cities[k].amount * 100) / 100; });
  return s;
}

// ===== Sheets.gs =====
/** Spreadsheet side: tabs, setup, refresh, change log. Every action is safe to run again. */

var NYYO_SAMPLE_ = [
  ['C-1001', '  alice smith ', '555-0101', '01/15/2025', '$1,200.50', 'paid', 'boston'],
  ['C-1002', 'Bob Jones', '+1 555 0102', '2025-01-20', '800', 'PAID', 'Boston'],
  ['c-1001 ', 'alice smith', '5550101', '15/01/2025', '1200.5', 'Paid', 'BOSTON'],
  ['', 'Carol Nguyen', '555.0103', 'Feb 3 2025', '950 USD ', 'pending', 'denver'],
  ['C-1004', '  DANIEL  LEE', '(555) 010-4', '2025/02/10', '2,100.00 USD', 'paid ', 'seattle'],
  ['C-1005', 'Eve Martin', 'n/a', '32/13/2025', 'abc', 'unknown', ''],
  ['C-1002', 'Bob Jones', '555-0102', '20-01-2025', '800.00', 'paid', 'boston'],
  ['C-1006', 'Fatima Zahra', '+44 7700 900123', '2025-03-01', '450,75', 'pending', 'Austin'],
  ['C-1007', '', '555', '2025-03-05', '0', 'paid', 'Miami'],
  ['C-1008', 'Hugo Blanc', '05550109', '05/03/25', '1 350', 'PAID', 'chicago']
];

/** Text of the "How to use" tab (a function, so it never depends on the order the files load in). */
function nyyoHowto_() {
  return [
  ['Nyyo Sheets kit ' + NYYO.version + ' - how to use'],
  [''],
  ['1. Put your rows in the "Data" tab (one row per client). Keep the header row. Column order does not matter.'],
  ['2. Menu Nyyo kit > "2. Clean + refresh dashboard". The "Clean" and "Dashboard" tabs are rebuilt from Data.'],
  ['   Your Data tab is never changed by the cleaning: it only reads it.'],
  ['3. Rows with a date, amount or status the kit cannot read are kept at the bottom of "Clean" with a'],
  ['   "NEEDS REVIEW" note. Fix them in Data, then run step 2 again.'],
  ['4. Duplicates (same client_id, or same name + phone when client_id is empty) are merged into one row.'],
  ['5. When you edit a row in Data, its "last_updated" cell gets the date and time automatically.'],
  ['6. Optional: Nyyo kit > "Turn on daily refresh" runs step 2 every morning. "Turn off daily refresh" stops it.'],
  [''],
  ['Accepted dates: 2025-01-15, 01/15/2025, 15/01/2025, 2025/01/15, 15-01-2025, Jan 15 2025, 15/01/25, or a date cell.'],
  ['Accepted amounts: 1200.5, $1,200.50, 2,100.00 USD, 450,75 (comma decimals), 1 350.'],
  ['Every action is written to the "Change log" tab. Running any menu item again is safe.'],
  ['This tab is rewritten by "1. Set up": write your own notes in another tab.'],
  [''],
  ['Questions? Ask in your order chat.']
  ];
}

function nyyoSs_() { return SpreadsheetApp.getActiveSpreadsheet(); }
function nyyoTz_(ss) { return (ss && ss.getSpreadsheetTimeZone && ss.getSpreadsheetTimeZone()) || Session.getScriptTimeZone() || 'Etc/UTC'; }
function nyyoNow_(ss) { return Utilities.formatDate(new Date(), nyyoTz_(ss), 'yyyy-MM-dd HH:mm:ss'); }

function nyyoToast_(msg) {
  try { nyyoSs_().toast(msg, 'Nyyo kit', 6); } catch (e) { /* no UI when run by a trigger */ }
  try { console.log(msg); } catch (e) { /* ignore */ }
  return msg;
}

/** Gets a tab, creating it (empty) only when it does not exist yet. */
function nyyoTab_(ss, name) {
  var sh = ss.getSheetByName(name);
  return sh ? { sheet: sh, created: false } : { sheet: ss.insertSheet(name), created: true };
}

function nyyoLog_(action, details) {
  var ss = nyyoSs_();
  var t = nyyoTab_(ss, NYYO.tabs.log), sh = t.sheet;
  if (t.created || sh.getLastRow() === 0) {
    sh.getRange(1, 1, 1, 3).setValues([['when', 'action', 'details']]).setFontWeight('bold');
    sh.setFrozenRows(1);
  }
  sh.appendRow([nyyoNow_(ss), action, details]);
  var extra = sh.getLastRow() - 1 - NYYO.logMaxRows;
  if (extra > 0) sh.deleteRows(2, extra);
}

/** Data header: adds missing kit columns at the end of row 1. Never renames, moves or deletes a column. */
function nyyoEnsureDataHeader_(sh) {
  var lastCol = Math.max(sh.getLastColumn(), 1);
  var header = sh.getLastRow() ? sh.getRange(1, 1, 1, lastCol).getValues()[0] : [];
  var have = header.map(function (h) { return nyyoNormText_(h).toLowerCase(); });
  var used = have.filter(function (h) { return h; }).length;
  var missing = NYYO.headers.filter(function (h) { return have.indexOf(h) === -1; });
  if (missing.length) {
    var start = used ? lastCol + 1 : 1;
    sh.getRange(1, start, 1, missing.length).setValues([missing]);
  }
  sh.getRange(1, 1, 1, sh.getLastColumn()).setFontWeight('bold');
  sh.setFrozenRows(1);
  return missing;
}

function nyyoDataRows_(sh) {
  var lastRow = sh.getLastRow(), lastCol = sh.getLastColumn();
  if (lastRow < 1 || lastCol < 1) return { header: [], rows: [] };
  var all = sh.getRange(1, 1, lastRow, lastCol).getValues();
  var rows = all.slice(1).filter(function (r) { return r.some(function (c) { return nyyoNormText_(c) !== ''; }); });
  return { header: all[0], rows: rows };
}

/** Writes the sample rows into Data, only when Data has no rows yet. */
function nyyoLoadSampleInto_(sh) {
  if (nyyoDataRows_(sh).rows.length) return false;
  var col = nyyoColumnMap_(sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0], NYYO.headers);
  var width = sh.getLastColumn();
  var order = ['client_id', 'name', 'phone', 'signup_date', 'amount_usd', 'status', 'city'];
  var out = NYYO_SAMPLE_.map(function (r) {
    var row = []; for (var i = 0; i < width; i++) row.push('');
    order.forEach(function (h, i) { row[col[h]] = r[i]; });
    return row;
  });
  var tsCol = col[NYYO.timestampColumn];
  sh.getRange(2, 1, out.length, width).setNumberFormat('@').setValues(out);
  if (tsCol !== undefined) sh.getRange(2, tsCol + 1, out.length, 1).setNumberFormat('General');
  return true;
}

/** Menu "1. Set up": creates what is missing, rewrites "How to use", then cleans. Safe to run again. */
function nyyoSetup() {
  var ss = nyyoSs_(), done = [];
  var data = nyyoTab_(ss, NYYO.tabs.data);
  var missing = nyyoEnsureDataHeader_(data.sheet);
  if (data.created) done.push('created tab ' + NYYO.tabs.data);
  else if (missing.length) done.push('added column(s) ' + missing.join(', '));
  if (data.created && nyyoLoadSampleInto_(data.sheet)) done.push('loaded ' + NYYO_SAMPLE_.length + ' sample rows');
  [NYYO.tabs.clean, NYYO.tabs.dashboard].forEach(function (n) { if (nyyoTab_(ss, n).created) done.push('created tab ' + n); });
  var howto = nyyoTab_(ss, NYYO.tabs.howto), text = nyyoHowto_();
  if (howto.created) done.push('created tab ' + NYYO.tabs.howto);
  howto.sheet.clearContents();
  howto.sheet.getRange(1, 1, text.length, 1).setValues(text);
  howto.sheet.getRange(1, 1).setFontWeight('bold');
  nyyoLog_('setup', done.length ? done.join('; ') : 'nothing to create (already set up)');
  var r = nyyoRefresh();
  return nyyoToast_('Set up done. ' + (done.length ? done.join('; ') + '. ' : 'Nothing to create. ') + r);
}

/** Menu "Load sample data": only when the Data tab has no rows. */
function nyyoLoadSample() {
  var ss = nyyoSs_(), data = nyyoTab_(ss, NYYO.tabs.data);
  nyyoEnsureDataHeader_(data.sheet);
  if (!nyyoLoadSampleInto_(data.sheet)) return nyyoToast_('Data already has rows: sample not loaded (nothing changed).');
  nyyoLog_('sample', 'loaded ' + NYYO_SAMPLE_.length + ' sample rows');
  return nyyoToast_('Sample rows loaded. ' + nyyoRefresh());
}

/** Menu "2. Clean + refresh dashboard". Reads Data, rebuilds Clean and Dashboard. Never writes to Data. */
function nyyoRefresh() {
  var ss = nyyoSs_();
  var dataSh = ss.getSheetByName(NYYO.tabs.data);
  if (!dataSh) return nyyoToast_('No "' + NYYO.tabs.data + '" tab yet: run "1. Set up" first.');
  var d = nyyoDataRows_(dataSh);
  if (!d.rows.length) {
    nyyoLog_('refresh', 'skipped: Data has no rows (Clean and Dashboard kept as they were)');
    return nyyoToast_('Data has no rows: Clean and Dashboard kept as they were.');
  }
  var res;
  try {
    res = nyyoCleanRows_(d.header, d.rows, NYYO, nyyoTz_(ss));
  } catch (e) {
    nyyoLog_('refresh', 'stopped: ' + e.message);
    return nyyoToast_(e.message);
  }
  // everything is computed before anything is cleared, so an error never leaves an empty tab
  var clean = nyyoTab_(ss, NYYO.tabs.clean).sheet;
  clean.clearContents();
  var table = [NYYO.cleanHeaders].concat(res.rows);
  clean.getRange(1, 1, table.length, NYYO.cleanHeaders.length).setNumberFormat('@').setValues(table);
  var amountCol = NYYO.cleanHeaders.indexOf('amount_usd') + 1;
  if (res.rows.length) clean.getRange(2, amountCol, res.rows.length, 1).setNumberFormat('0.00');
  clean.getRange(1, 1, 1, NYYO.cleanHeaders.length).setFontWeight('bold');
  clean.setFrozenRows(1);
  nyyoWriteDashboard_(ss, res);
  var msg = res.kept + ' clean row(s), ' + res.merged + ' duplicate(s) merged, ' + res.review + ' to review, ' +
    res.skipped + ' empty-name row(s) skipped.';
  nyyoLog_('refresh', msg);
  return msg;
}

function nyyoWriteDashboard_(ss, res) {
  var s = nyyoSummary_(res.rows, NYYO);
  var sh = nyyoTab_(ss, NYYO.tabs.dashboard).sheet;
  var rows = [
    ['Dashboard', 'value'],
    ['Last refresh', nyyoNow_(ss)],
    ['Clean clients', s.clients],
    ['Duplicates merged', res.merged],
    ['Rows to review', s.review],
    ['Paid (count)', s.paidCount],
    ['Paid (USD)', s.paid],
    ['Pending (count)', s.pendingCount],
    ['Pending (USD)', s.pending],
    ['', ''],
    ['City', 'clients / USD']
  ];
  Object.keys(s.cities).sort().forEach(function (k) { rows.push([k, s.cities[k].count + ' / ' + s.cities[k].amount.toFixed(2)]); });
  sh.clearContents();
  sh.getRange(1, 1, rows.length, 2).setValues(rows);
  sh.getRange(1, 1, 1, 2).setFontWeight('bold');
  sh.getRange(11, 1, 1, 2).setFontWeight('bold');
  return s;
}

// ===== Triggers.gs =====
/** Automations: last_updated stamp on edit (simple trigger) and the optional daily refresh (installable trigger). */

/** Simple trigger: runs by itself when someone edits the Data tab. Stamps the edited rows' last_updated cell. */
function onEdit(e) {
  if (!e || !e.range) return;
  var sh = e.range.getSheet();
  if (sh.getName() !== NYYO.tabs.data) return;
  var top = e.range.getRow(), n = e.range.getNumRows();
  if (top === 1) { top = 2; n--; }  // header edits are not stamped
  if (n < 1) return;
  var header = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0]
    .map(function (h) { return nyyoNormText_(h).toLowerCase(); });
  var ts = header.indexOf(NYYO.timestampColumn) + 1;
  if (!ts) return;
  var c1 = e.range.getColumn(), c2 = c1 + e.range.getNumColumns() - 1;
  if (c1 === ts && c2 === ts) return;  // editing the stamp itself: leave it alone (no loop)
  var now = nyyoNow_(sh.getParent ? sh.getParent() : nyyoSs_());
  var vals = []; for (var i = 0; i < n; i++) vals.push([now]);
  sh.getRange(top, ts, n, 1).setValues(vals);
}

function nyyoKitTriggers_() {
  return ScriptApp.getProjectTriggers().filter(function (t) { return t.getHandlerFunction() === 'nyyoDailyRefresh'; });
}

/** Menu "Turn on daily refresh": exactly one daily trigger, however many times you click. */
function nyyoEnableDailyRefresh() {
  var old = nyyoKitTriggers_();
  old.forEach(function (t) { ScriptApp.deleteTrigger(t); });
  ScriptApp.newTrigger('nyyoDailyRefresh').timeBased().everyDays(1).atHour(NYYO.dailyRefreshHour).create();
  nyyoLog_('daily refresh', 'on, around ' + NYYO.dailyRefreshHour + ':00' + (old.length ? ' (replaced ' + old.length + ' older trigger(s))' : ''));
  return nyyoToast_('Daily refresh is on (around ' + NYYO.dailyRefreshHour + ':00, spreadsheet time zone).');
}

/** Menu "Turn off daily refresh". */
function nyyoDisableDailyRefresh() {
  var old = nyyoKitTriggers_();
  old.forEach(function (t) { ScriptApp.deleteTrigger(t); });
  nyyoLog_('daily refresh', 'off (' + old.length + ' trigger(s) removed)');
  return nyyoToast_('Daily refresh is off.');
}

/** Run by the daily trigger. The lock stops two refreshes from overlapping. */
function nyyoDailyRefresh() {
  var lock = LockService.getDocumentLock();
  if (!lock.tryLock(30000)) return 'busy';
  try { return nyyoRefresh(); } finally { lock.releaseLock(); }
}

// ===== Menu.gs =====
/** The "Nyyo kit" menu. It appears each time the spreadsheet is opened (reload the tab after installing). */

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('Nyyo kit')
    .addItem('1. Set up (safe to run again)', 'nyyoSetup')
    .addItem('2. Clean + refresh dashboard', 'nyyoRefresh')
    .addSeparator()
    .addItem('Load sample data (empty Data tab only)', 'nyyoLoadSample')
    .addItem('Turn on daily refresh', 'nyyoEnableDailyRefresh')
    .addItem('Turn off daily refresh', 'nyyoDisableDailyRefresh')
    .addSeparator()
    .addItem('About this kit', 'nyyoAbout')
    .addToUi();
}

function onInstall(e) { onOpen(e); }

function nyyoAbout() {
  return nyyoToast_('Nyyo Sheets kit ' + NYYO.version + ' (MIT). Guide: the "How to use" tab. Questions? Ask in your order chat.');
}
